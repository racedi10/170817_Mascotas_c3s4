package mx.com.oexl.petagram.pojo;

/**
 * Created by Raul on 30/08/2017.
 */
public class Contacto {
}
